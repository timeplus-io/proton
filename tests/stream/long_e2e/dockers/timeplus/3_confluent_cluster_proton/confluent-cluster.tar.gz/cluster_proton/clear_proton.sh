rm -rf ./proton-cluster-node1/datas
rm -rf ./proton-cluster-node1/log
rm -rf ./proton-cluster-node2/datas
rm -rf ./proton-cluster-node2/log
rm -rf ./proton-cluster-node3/datas
rm -rf ./proton-cluster-node3/log
